from functions.function_library import *

user_first_name = get_first_name()

print("Welcome, " + user_first_name)