## File that contains the show_magicians function

def show_magicians(passed_list):
    print("\n")
    for magician in passed_list:
        print(magician + '\n')