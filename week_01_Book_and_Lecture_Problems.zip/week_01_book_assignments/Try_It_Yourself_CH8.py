## 8-15 Printing Functions Models
## 06/30/2019
## Brohl, Steven

import functions.printing_functions as print_functions

unprinted_designs = ['iphone case', 'robot pendant', 'dodecahedron']
completed_models = []

print_functions.print_models(unprinted_designs, completed_models)
print_functions.show_completed_models(completed_models)




## 8-16 Imports
## 06/30/2019
## Brohl Steven

import functions.show_magicians as show_magicians

## List of Magicians
magicians = ["Merlin", "Houdini", "Blaine", "Angel"]

show_magicians.show_magicians(magicians)




